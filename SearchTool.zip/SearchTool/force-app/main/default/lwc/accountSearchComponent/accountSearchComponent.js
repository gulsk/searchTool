import { LightningElement,track,wire,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getAccounts from '@salesforce/apex/AccountSearchComponentController.getAccounts';
import searchAccounts from '@salesforce/apex/AccountSearchComponentController.getSearchedAccounts';
import updateAccounts from '@salesforce/apex/AccountSearchComponentController.updateAccounts';
import { refreshApex } from '@salesforce/apex';

const cols = [
    { label: 'Account Name', fieldName: 'Name', editable: true },
    { label: 'Country', fieldName: 'BillingCountry', type: 'address' },
    { label: 'City', fieldName: 'BillingCity', type: 'address' },
    { label: 'Street', fieldName: 'BillingStreet', type: 'address' }
];

export default class AccountSearchComponent extends LightningElement {
    
    columns = cols;
    draftValues = [];
    searchVal = '';
    @track data;
    @track error;
    @wire(getAccounts)
    accounts({ error, data }) {
        if (data) {
            this.data = data;
        } else if (error) {
            this.error = error;
        }
    }

    getSearchKey(event) {
        this.searchVal = event.target.value;
    }

    handleSearchKey(){
        searchAccounts({ searchKey : this.searchVal})
        .then(result => {
            this.data =  result;
            if(data == null){
                const event = new ShowToastEvent({
                    title: 'Warning',
                    variant: 'Invalid search! Please try again.',
                    message: 'Warning',
                });
            }
        })
        .catch(error => {
            const event = new ShowToastEvent({
                title: 'Error',
                variant: 'Invalid search! Please try again.',
                message: 'Warning',
            });
        }); 
    }
    
    async handleSave(event) {
        const updatedFields = event.detail.draftValues;
        console.log(updatedFields);
        const notifyChangeIds = updatedFields.map(row => { return { "recordId": row.Id } });
        try {
            const result = await updateAccounts({data : updatedFields});
            console.log(JSON.stringify("Apex update result: "+ result));
            getRecordNotifyChange(notifyChangeIds);
            // Display fresh data in the datatable
            refreshApex(this.accounts).then(() => {
                // Clear all draft values in the datatable
                this.draftValues = [];
            });
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Accounts are updated!',
                    variant: 'success'
                })
            );
       } catch(error) {
               this.dispatchEvent(
                   new ShowToastEvent({
                       title: 'Error updating records',
                       message: 'Accounts cannot be updated',
                       variant: 'error'
                   })
             );
        };
    }
}